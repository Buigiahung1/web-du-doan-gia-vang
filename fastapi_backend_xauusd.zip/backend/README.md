# Backend FastAPI XAUUSD - Hệ Thống Dự Báo Giá Vàng Thế Giới

Dự án FastAPI được nâng cấp từ phiên bản Flask API cũ, tập trung chốt mô hình và dữ liệu trên tài sản **XAUUSD (Vàng thế giới Spot - USD/oz)**.

## 🚀 Hướng Dẫn Cài Đặt & Khởi Chạy

### 1. Chuẩn bị Môi trường Python
```bash
python -m venv venv
# On Windows:
venv\Scripts\activate
# On Linux/macOS:
source venv/bin/activate

pip install -r requirements.txt
```

### 2. Khởi tạo Cơ sở dữ liệu MySQL
1. Mở **MySQL Workbench** hoặc kết nối tới server MySQL của bạn.
2. Mở file `database.sql` và thực thi toàn bộ script để tạo database `gold_prediction` và các bảng.

### 3. Cấu hình Môi trường `.env`
Tạo file `.env` từ `.env.example` và cập nhật thông tin kết nối CSDL:
```env
DATABASE_URL=mysql+pymysql://root:password@localhost:3306/gold_prediction
```

### 4. Import Dữ liệu Lịch sử XAUUSD từ CSV
Đảm bảo các file `XAU_1d_data.csv`, `XAUUSD_12h.csv`, `XAUUSD_1h.csv` nằm trong thư mục gốc dự án, sau đó chạy:
```bash
python import_gold_data.py
```

### 5. Khởi chạy Web API Server
```bash
uvicorn app.main:app --reload --port 8000
```
Truy cập tài liệu OpenAPI / Swagger tại: `http://localhost:8000/docs`
