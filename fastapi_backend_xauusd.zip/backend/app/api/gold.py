import datetime as dt
from typing import Literal
from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy import select, func
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.gold import GoldPrice, GoldType
from app.schemas.gold import CurrentOut, HistoryOut, CandleOut

router = APIRouter(prefix="/api/gold", tags=["gold"])

@router.get("/current", response_model=CurrentOut)
def get_current_gold(
    gold_type: str = Query("XAUUSD", description="Mã loại vàng"),
    timeframe: str = Query("1d", description="Khung thời gian (1d, 1h, 12h)"),
    db: Session = Depends(get_db)
):
    gt = db.scalar(select(GoldType).where(GoldType.code == gold_type))
    if not gt:
        raise HTTPException(status_code=404, detail=f"Không tìm thấy loại tài sản {gold_type}")

    price = db.scalar(
        select(GoldPrice)
        .where(GoldPrice.gold_type_id == gt.id, GoldPrice.timeframe == timeframe)
        .order_by(GoldPrice.date.desc())
        .limit(1)
    )
    if not price:
        raise HTTPException(status_code=404, detail="Chưa có dữ liệu giá vàng")

    return CurrentOut(
        gold_type=gt.code,
        unit=gt.unit,
        date=price.date.date() if isinstance(price.date, dt.datetime) else price.date,
        open=price.open,
        high=price.high,
        low=price.low,
        close=price.close,
        volume=price.volume
    )

@router.get("/history", response_model=HistoryOut)
def get_gold_history(
    gold_type: str = Query("XAUUSD"),
    timeframe: str = Query("1d"),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=500),
    order: Literal["asc", "desc"] = "desc",
    db: Session = Depends(get_db)
):
    gt = db.scalar(select(GoldType).where(GoldType.code == gold_type))
    if not gt:
        raise HTTPException(status_code=404, detail=f"Không tìm thấy mã {gold_type}")

    base_query = select(GoldPrice).where(GoldPrice.gold_type_id == gt.id, GoldPrice.timeframe == timeframe)
    total = db.scalar(select(func.count()).select_from(base_query.subquery())) or 0

    order_col = GoldPrice.date.desc() if order == "desc" else GoldPrice.date.asc()
    offset = (page - 1) * page_size
    rows = db.scalars(base_query.order_by(order_col).offset(offset).limit(page_size)).all()

    items = [
        CandleOut(
            date=r.date,
            open=r.open,
            high=r.high,
            low=r.low,
            close=r.close,
            volume=r.volume
        ) for r in rows
    ]

    return HistoryOut(
        gold_type=gt.code,
        timeframe=timeframe,
        page=page,
        page_size=page_size,
        total=total,
        items=items
    )
