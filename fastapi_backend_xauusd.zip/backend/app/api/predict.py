from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.core.ratelimit import predict_rate_limit
from app.db.session import get_db
from app.schemas.predict import PredictOut, PredictRequest
from app.services.predict_service import predict_service
from app.models.user import User

router = APIRouter(prefix="/api", tags=["predict"])

@router.post("/predict", response_model=PredictOut, dependencies=[Depends(predict_rate_limit)])
def create_prediction(
    body: PredictRequest,
    db: Session = Depends(get_db),
    user: User | None = Depends(get_current_user)
):
    try:
        user_id = user.id if user else None
        return predict_service.predict_xauusd(db=db, horizon_days=body.horizon_days, user_id=user_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
