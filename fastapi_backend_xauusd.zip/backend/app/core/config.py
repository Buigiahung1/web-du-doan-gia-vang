from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    database_url: str = "mysql+pymysql://root:password@localhost:3306/gold_prediction"
    cors_origins: str = "http://localhost:5173,http://localhost:3000"
    model_dir: str = "../models"
    default_gold_type: str = "XAUUSD"
    jwt_secret: str = "super_secret_jwt_key_change_in_production"
    access_token_expire_minutes: int = 1440
    predict_timeout_s: float = 10.0
    predict_rate_limit_per_min: int = 30
    cache_ttl_s: int = 60

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

settings = Settings()
