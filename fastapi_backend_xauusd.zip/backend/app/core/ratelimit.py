import time
import threading
from collections import defaultdict, deque
from fastapi import Request
from app.core.errors import AppError
from app.core.config import settings

class RateLimiter:
    def __init__(self, limit: int, window_s: float = 60):
        self.limit = limit
        self.window_s = window_s
        self._hits = defaultdict(deque)
        self._lock = threading.Lock()

    def allow(self, key: str) -> bool:
        now = time.monotonic()
        with self._lock:
            q = self._hits[key]
            while q and now - q[0] > self.window_s:
                q.popleft()
            if len(q) >= self.limit:
                return False
            q.append(now)
            return True

predict_limiter = RateLimiter(limit=settings.predict_rate_limit_per_min)

def predict_rate_limit(request: Request) -> None:
    key = request.client.host if request.client else "unknown"
    if not predict_limiter.allow(key):
        raise AppError(429, "RATE_LIMITED", "Bạn thao tác quá nhanh, vui lòng thử lại sau ít phút.")
