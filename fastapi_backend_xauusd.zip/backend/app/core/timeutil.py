import datetime as dt

VN_TZ = dt.timezone(dt.timedelta(hours=7))

def utcnow_naive() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc).replace(tzinfo=None)

def to_vn(naive_utc: dt.datetime | None) -> dt.datetime | None:
    if naive_utc is None:
        return None
    return naive_utc.replace(tzinfo=dt.timezone.utc).astimezone(VN_TZ)

def now_vn() -> dt.datetime:
    return dt.datetime.now(VN_TZ)
