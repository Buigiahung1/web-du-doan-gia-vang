from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api import auth, gold, predict
from app.core.config import settings
from app.core.errors import register_exception_handlers

@asynccontextmanager
async def lifespan(app: FastAPI):
    print("🚀 FastAPI XAUUSD Server is starting up...")
    yield
    print("🛑 FastAPI Server shut down.")

app = FastAPI(
    title="XAUUSD Gold Prediction API",
    version="2.0.0",
    description="FastAPI Backend dự báo giá vàng XAUUSD sử dụng MySQL & Machine Learning",
    lifespan=lifespan
)

register_exception_handlers(app)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(gold.router)
app.include_router(predict.router)

@app.get("/")
def root():
    return {"status": "online", "system": "XAUUSD Prediction API", "version": "2.0.0"}

@app.get("/api/health")
def health():
    return {"status": "healthy"}
