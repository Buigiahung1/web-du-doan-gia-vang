from app.models.gold import GoldPrice, GoldType
from app.models.user import User
from app.models.prediction import MlModel, Prediction, PredictionItem
