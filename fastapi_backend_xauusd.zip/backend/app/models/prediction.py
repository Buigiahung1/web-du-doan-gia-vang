import datetime as dt
from sqlalchemy import DateTime, ForeignKey, JSON, String, Boolean, func
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base import Base
from app.models.gold import Price

class MlModel(Base):
    __tablename__ = "ml_models"
    
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(50))
    algorithm: Mapped[str] = mapped_column(String(50))
    version: Mapped[str] = mapped_column(String(20))
    artifact_path: Mapped[str] = mapped_column(String(255))
    metrics: Mapped[dict | None] = mapped_column(JSON)
    is_active: Mapped[bool] = mapped_column(Boolean, default=False)
    trained_at: Mapped[dt.datetime | None] = mapped_column(DateTime)

class Prediction(Base):
    __tablename__ = "predictions"
    
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), index=True)
    gold_type_id: Mapped[int] = mapped_column(ForeignKey("gold_types.id", ondelete="CASCADE"))
    ml_model_id: Mapped[int] = mapped_column(ForeignKey("ml_models.id", ondelete="CASCADE"))
    horizon_days: Mapped[int] = mapped_column(default=1)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime, server_default=func.now())

    gold_type = relationship("GoldType")
    ml_model = relationship("MlModel")
    items: Mapped[list["PredictionItem"]] = relationship(back_populates="prediction", cascade="all, delete-orphan")

class PredictionItem(Base):
    __tablename__ = "prediction_items"
    
    id: Mapped[int] = mapped_column(primary_key=True)
    prediction_id: Mapped[int] = mapped_column(ForeignKey("predictions.id", ondelete="CASCADE"))
    target_date: Mapped[dt.date]
    predicted_price: Mapped[float] = mapped_column(Price)
    lower_bound: Mapped[float | None] = mapped_column(Price)
    upper_bound: Mapped[float | None] = mapped_column(Price)
    actual_price: Mapped[float | None] = mapped_column(Price)

    prediction: Mapped[Prediction] = relationship(back_populates="items")
