import datetime as dt
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from app.models.gold import GoldPrice, GoldType

def list_types(db: Session) -> list[GoldType]:
    return list(db.scalars(select(GoldType).order_by(GoldType.id)))

def get_type_by_code(db: Session, code: str) -> GoldType | None:
    return db.scalar(select(GoldType).where(GoldType.code == code))

def latest_price(db: Session, gold_type_id: int, timeframe: str = "1d") -> GoldPrice | None:
    return db.scalar(
        select(GoldPrice)
        .where(GoldPrice.gold_type_id == gold_type_id, GoldPrice.timeframe == timeframe)
        .order_by(GoldPrice.date.desc())
        .limit(1)
    )
