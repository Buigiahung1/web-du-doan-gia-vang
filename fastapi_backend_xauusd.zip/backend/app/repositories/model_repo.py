from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models.prediction import MlModel

def list_models(db: Session) -> list[MlModel]:
    return list(db.scalars(select(MlModel).order_by(MlModel.id)))

def get_active_model(db: Session) -> MlModel | None:
    return db.scalar(select(MlModel).where(MlModel.is_active.is_(True)).limit(1))
