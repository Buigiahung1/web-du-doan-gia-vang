from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models.prediction import Prediction

def list_for_user(db: Session, user_id: int, offset: int, limit: int) -> tuple[int, list[Prediction]]:
    total = db.scalar(select(func.count(Prediction.id)).where(Prediction.user_id == user_id)) or 0
    rows = db.scalars(
        select(Prediction)
        .where(Prediction.user_id == user_id)
        .order_by(Prediction.created_at.desc())
        .offset(offset).limit(limit)
    )
    return total, list(rows)
