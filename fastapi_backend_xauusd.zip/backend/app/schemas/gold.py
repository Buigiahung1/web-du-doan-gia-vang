import datetime as dt
from pydantic import BaseModel, ConfigDict

class GoldTypeOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    code: str
    name: str
    unit: str
    source: str | None = None

class CandleOut(BaseModel):
    date: dt.datetime
    open: float
    high: float
    low: float
    close: float
    volume: float | None = None

class HistoryOut(BaseModel):
    gold_type: str
    timeframe: str
    page: int
    page_size: int
    total: int
    items: list[CandleOut]

class CurrentOut(BaseModel):
    gold_type: str
    unit: str
    date: dt.date
    open: float
    high: float
    low: float
    close: float
    volume: float | None = None
