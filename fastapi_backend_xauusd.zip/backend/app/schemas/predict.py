import datetime as dt
from typing import Literal
from pydantic import BaseModel, Field

class PredictRequest(BaseModel):
    gold_type: str = Field(default="XAUUSD", max_length=50)
    horizon_days: int = Field(default=1, ge=1, le=7)
    model_id: int | None = Field(default=None, ge=1)

class PredictItemOut(BaseModel):
    target_date: dt.date
    predicted_price: float
    lower_bound: float | None = None
    upper_bound: float | None = None

class PredictOut(BaseModel):
    gold_type: str
    last_actual_price: float
    last_actual_date: dt.date
    trend: Literal["up", "down", "flat"]
    horizon_days: int
    items: list[PredictItemOut]
