from sqlalchemy.orm import Session
from app.core.errors import AppError
from app.repositories import gold_repo

def require_type(db: Session, code: str):
    gt = gold_repo.get_type_by_code(db, code)
    if gt is None:
        raise AppError(404, "GOLD_TYPE_NOT_FOUND", f"Không tìm thấy loại tài sản '{code}'.")
    return gt
