import logging
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeout
import pandas as pd
from app.core.config import settings
from app.core.errors import AppError

logger = logging.getLogger("app.inference")
_pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix="infer")

def run_inference(predictor, df: pd.DataFrame, horizon: int, timeout_s: float) -> list[float]:
    fut = _pool.submit(predictor.predict, df, horizon)
    try:
        out = fut.result(timeout=timeout_s)
    except FutureTimeout:
        fut.cancel()
        raise AppError(504, "PREDICTION_TIMEOUT", "Quá thời gian dự báo.")
    except Exception as e:
        logger.exception("Model lỗi khi suy luận")
        raise AppError(500, "PREDICTION_FAILED", "Mô hình không thể thực hiện dự báo.") from e
    return [float(x) for x in out[:horizon]]
