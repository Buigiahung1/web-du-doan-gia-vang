from pathlib import Path
import joblib
from app.core.config import settings

class ModelRegistry:
    def __init__(self):
        self._models = {}

    def get_model(self, artifact_path: str):
        full_path = Path(settings.model_dir) / artifact_path
        if not full_path.exists():
            return None
        if artifact_path not in self._models:
            self._models[artifact_path] = joblib.load(full_path)
        return self._models[artifact_path]

registry = ModelRegistry()
