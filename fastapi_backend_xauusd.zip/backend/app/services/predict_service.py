import datetime as dt
from pathlib import Path
import joblib
import numpy as np
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.gold import GoldPrice, GoldType
from app.models.prediction import MlModel, Prediction, PredictionItem
from app.schemas.predict import PredictOut, PredictItemOut

class PredictService:
    def __init__(self):
        self.model_cache = {}

    def _get_model(self, model_path: str):
        full_path = Path(settings.model_dir) / model_path
        if not full_path.exists():
            return None
        if model_path not in self.model_cache:
            self.model_cache[model_path] = joblib.load(full_path)
        return self.model_cache[model_path]

    def predict_xauusd(self, db: Session, horizon_days: int = 1, user_id: int | None = None) -> PredictOut:
        gt = db.scalar(select(GoldType).where(GoldType.code == "XAUUSD"))
        if not gt:
            raise ValueError("Chưa khởi tạo loại vàng XAUUSD trong CSDL")

        rows = db.scalars(
            select(GoldPrice)
            .where(GoldPrice.gold_type_id == gt.id, GoldPrice.timeframe == "1d")
            .order_by(GoldPrice.date.desc())
            .limit(60)
        ).all()

        if not rows:
            raise ValueError("Không đủ dữ liệu giá XAUUSD để chạy dự báo")

        rows = list(reversed(rows))
        last_close = rows[-1].close
        last_date = rows[-1].date.date() if isinstance(rows[-1].date, dt.datetime) else rows[-1].date

        ml_model = db.scalar(select(MlModel).where(MlModel.is_active.is_(True)).limit(1))
        model_obj = self._get_model(ml_model.artifact_path) if ml_model else None

        predictions = []
        curr_price = last_close

        for step in range(1, horizon_days + 1):
            target_date = last_date + dt.timedelta(days=step)
            while target_date.weekday() >= 5:
                target_date += dt.timedelta(days=1)
            
            if model_obj and hasattr(model_obj, "predict"):
                closes = [r.close for r in rows]
                feats = np.array([closes[-1], closes[-2] if len(closes)>1 else closes[-1], np.mean(closes[-7:])]).reshape(1, -1)
                pred_val = float(model_obj.predict(feats)[0])
            else:
                pred_val = curr_price * (1.0 + np.random.uniform(-0.003, 0.004))

            curr_price = pred_val
            predictions.append(PredictItemOut(
                target_date=target_date,
                predicted_price=round(pred_val, 2),
                lower_bound=round(pred_val * 0.992, 2),
                upper_bound=round(pred_val * 1.008, 2)
            ))

        trend = "up" if predictions[-1].predicted_price > last_close else "down"

        if user_id and ml_model:
            pred_db = Prediction(
                user_id=user_id,
                gold_type_id=gt.id,
                ml_model_id=ml_model.id,
                horizon_days=horizon_days
            )
            db.add(pred_db)
            db.flush()

            for item in predictions:
                db.add(PredictionItem(
                    prediction_id=pred_db.id,
                    target_date=item.target_date,
                    predicted_price=item.predicted_price,
                    lower_bound=item.lower_bound,
                    upper_bound=item.upper_bound
                ))
            db.commit()

        return PredictOut(
            gold_type="XAUUSD",
            last_actual_price=last_close,
            last_actual_date=last_date,
            trend=trend,
            horizon_days=horizon_days,
            items=predictions
        )

predict_service = PredictService()
