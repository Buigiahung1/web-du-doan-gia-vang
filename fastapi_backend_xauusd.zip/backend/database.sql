-- Kịch bản SQL tạo Database và Bảng cho FastAPI Gold Prediction (Chốt XAUUSD)
CREATE DATABASE IF NOT EXISTS gold_prediction CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE gold_prediction;

-- 1. Bảng người dùng (Users)
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  email VARCHAR(100) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(100) NULL,
  role ENUM('user', 'admin') NOT NULL DEFAULT 'user',
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 2. Bảng loại tài sản vàng (Gold Types)
CREATE TABLE IF NOT EXISTS gold_types (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(50) NOT NULL UNIQUE,
  name VARCHAR(100) NOT NULL,
  unit VARCHAR(30) NOT NULL DEFAULT 'USD/oz',
  source VARCHAR(100) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 3. Bảng dữ liệu lịch sử giá vàng (Gold Prices)
CREATE TABLE IF NOT EXISTS gold_prices (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  gold_type_id INT NOT NULL,
  timeframe VARCHAR(10) NOT NULL DEFAULT '1d',
  `date` DATETIME NOT NULL,
  `open` DECIMAL(20,4) NOT NULL,
  high DECIMAL(20,4) NOT NULL,
  low DECIMAL(20,4) NOT NULL,
  close DECIMAL(20,4) NOT NULL,
  volume DECIMAL(24,4) NULL,
  buy DECIMAL(20,4) NULL,
  sell DECIMAL(20,4) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uq_gold_prices_type_tf_date UNIQUE (gold_type_id, timeframe, `date`),
  CONSTRAINT fk_gold_prices_type FOREIGN KEY (gold_type_id) REFERENCES gold_types(id) ON DELETE CASCADE,
  KEY idx_gold_prices_date (`date`),
  KEY idx_gold_prices_tf (timeframe)
) ENGINE=InnoDB;

-- 4. Bảng mô hình Machine Learning (ML Models)
CREATE TABLE IF NOT EXISTS ml_models (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL,
  algorithm VARCHAR(50) NOT NULL DEFAULT 'RandomForest',
  version VARCHAR(20) NOT NULL DEFAULT 'v1.0',
  artifact_path VARCHAR(255) NOT NULL,
  metrics JSON NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 0,
  trained_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 5. Bảng phiên dự báo (Predictions)
CREATE TABLE IF NOT EXISTS predictions (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  gold_type_id INT NOT NULL,
  ml_model_id INT NOT NULL,
  horizon_days INT NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_predictions_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_predictions_gold_type FOREIGN KEY (gold_type_id) REFERENCES gold_types(id) ON DELETE CASCADE,
  CONSTRAINT fk_predictions_model FOREIGN KEY (ml_model_id) REFERENCES ml_models(id) ON DELETE CASCADE,
  KEY idx_predictions_user (user_id)
) ENGINE=InnoDB;

-- 6. Bảng chi tiết kết quả dự báo (Prediction Items)
CREATE TABLE IF NOT EXISTS prediction_items (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  prediction_id BIGINT NOT NULL,
  target_date DATE NOT NULL,
  predicted_price DECIMAL(20,4) NOT NULL,
  lower_bound DECIMAL(20,4) NULL,
  upper_bound DECIMAL(20,4) NULL,
  actual_price DECIMAL(20,4) NULL,
  CONSTRAINT fk_pred_items_prediction FOREIGN KEY (prediction_id) REFERENCES predictions(id) ON DELETE CASCADE,
  KEY idx_pred_items_target (target_date)
) ENGINE=InnoDB;

-- Seed dữ liệu mặc định ban đầu
INSERT INTO gold_types (code, name, unit, source) 
VALUES ('XAUUSD', 'Vàng Thế Giới Spot (XAU/USD)', 'USD/oz', 'HISTORICAL_CSV')
ON DUPLICATE KEY UPDATE name=VALUES(name);

INSERT INTO ml_models (name, algorithm, version, artifact_path, is_active)
VALUES ('XAUUSD Random Forest Predictor', 'RandomForestRegressor', 'v1.0', 'random_forest_xauusd.joblib', 1)
ON DUPLICATE KEY UPDATE is_active=VALUES(is_active);

INSERT INTO users (username, email, password_hash, role)
VALUES ('admin', 'admin@goldprediction.com', '$2b$12$eImiTXuWVxfM37uY4JANjO5E/qRjUqO1G8r7k8P9lD9j0j1n2m3k4', 'admin')
ON DUPLICATE KEY UPDATE role=VALUES(role);
