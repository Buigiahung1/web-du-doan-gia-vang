from pathlib import Path
import os
import pandas as pd
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / ".env")

DB_URL = os.getenv("DATABASE_URL", "mysql+pymysql://root:password@localhost:3306/gold_prediction")
engine = create_engine(DB_URL)

DATASETS = [
    ("XAU_1d_data.csv", ";", "1d", "Date"),
    ("XAUUSD_12h.csv", ",", "12h", "datetime"),
    ("XAUUSD_1h.csv", ",", "1h", "datetime"),
]

def run_import():
    with engine.connect() as conn:
        gt_res = conn.execute(text("SELECT id FROM gold_types WHERE code='XAUUSD'")).fetchone()
        if not gt_res:
            conn.execute(text("INSERT INTO gold_types (code, name, unit) VALUES ('XAUUSD', 'Vàng Thế Giới Spot', 'USD/oz')"))
            conn.commit()
            gt_id = conn.execute(text("SELECT id FROM gold_types WHERE code='XAUUSD'")).fetchone()[0]
        else:
            gt_id = gt_res[0]

        for filename, sep, timeframe, date_col in DATASETS:
            path = ROOT / filename
            if not path.exists():
                path = ROOT.parent / filename
            if not path.exists():
                print(f"Bỏ qua {filename}: Không tìm thấy file.")
                continue

            print(f"Đang import dataset: {filename} ({timeframe})...")
            df = pd.read_csv(path, sep=sep)
            df.columns = [c.lower().strip() for c in df.columns]
            date_col_lower = date_col.lower()

            if date_col_lower not in df.columns:
                print(f"Không tìm thấy cột {date_col} trong {filename}")
                continue

            if timeframe == "1d":
                df["parsed_date"] = pd.to_datetime(df[date_col_lower], format="%Y.%m.%d %H:%M", errors="coerce")
            else:
                df["parsed_date"] = pd.to_datetime(df[date_col_lower], errors="coerce", utc=True).dt.tz_localize(None)

            df = df.dropna(subset=["parsed_date", "open", "high", "low", "close"])
            
            records = []
            for _, r in df.iterrows():
                vol = float(r["volume"]) if "volume" in r and pd.notna(r["volume"]) else None
                records.append({
                    "gold_type_id": gt_id,
                    "timeframe": timeframe,
                    "date": r["parsed_date"],
                    "open": float(r["open"]),
                    "high": float(r["high"]),
                    "low": float(r["low"]),
                    "close": float(r["close"]),
                    "volume": vol
                })

            stmt = text("""
                INSERT INTO gold_prices (gold_type_id, timeframe, date, open, high, low, close, volume)
                VALUES (:gold_type_id, :timeframe, :date, :open, :high, :low, :close, :volume)
                ON DUPLICATE KEY UPDATE 
                    open=VALUES(open), high=VALUES(high), low=VALUES(low), close=VALUES(close), volume=VALUES(volume)
            """)
            
            conn.execute(stmt, records)
            conn.commit()
            print(f"Thành công import {len(records)} bản ghi cho {filename} ({timeframe}).")

if __name__ == "__main__":
    run_import()
